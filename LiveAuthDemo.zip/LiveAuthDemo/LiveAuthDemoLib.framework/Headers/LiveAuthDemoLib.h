//
//  LiveAuthDemoLib.h
//  LiveAuthDemoLib
//
//  Created by Özgün Ergen on 10.03.2023.
//

#import <Foundation/Foundation.h>

//! Project version number for LiveAuthDemoLib.
FOUNDATION_EXPORT double LiveAuthDemoLibVersionNumber;

//! Project version string for LiveAuthDemoLib.
FOUNDATION_EXPORT const unsigned char LiveAuthDemoLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LiveAuthDemoLib/PublicHeader.h>


